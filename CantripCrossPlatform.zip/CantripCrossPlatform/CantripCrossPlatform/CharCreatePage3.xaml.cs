﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace CantripCrossPlatform
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class CharCreatePage3 : ContentPage
    {
        public CharCreatePage3()
        {
            this.Title = "Skills & Proficiency";
            InitializeComponent();
        }
    }
}