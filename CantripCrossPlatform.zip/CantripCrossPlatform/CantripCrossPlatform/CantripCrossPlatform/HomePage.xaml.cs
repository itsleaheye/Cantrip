﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SQLite;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using System.IO;
using CantripCrossPlatform.Assets;

namespace CantripCrossPlatform
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class HomePage : ContentPage
    {
        private ListView characterListView;
        string dbPath = Path.Combine(System.Environment.GetFolderPath(System.Environment.SpecialFolder.Personal), "myDV.db3");
        public HomePage()
        {
            this.Title = "Home";

            StackLayout stackLayout = new StackLayout();
            var db = new SQLiteConnection(dbPath);
            //Add error handling if no characters exist
            characterListView = new ListView();
            characterListView.ItemsSource = db.Table<Character>().OrderBy(x => x.Name).ToList();
            stackLayout.Children.Add(characterListView);

            Button button = new Button();
            button.Text = "New Character";
            button.Clicked += Button_Clicked;
            stackLayout.Children.Add(button);

            Content = stackLayout;

        }
        private async void Button_Clicked(object sender, EventArgs e)
        {
            await Navigation.PushAsync(new CharCreatePage());
        }

    }
}