﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SQLite;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using System.IO;
using CantripCrossPlatform.Assets;

namespace CantripCrossPlatform
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class HomePage : ContentPage
    {
        string dbPath = Path.Combine(System.Environment.GetFolderPath(System.Environment.SpecialFolder.Personal), "myDV.db3"); //Declare database pathing
        public HomePage()
        {
            this.Title = "My Characters";
            InitializeComponent(); //Load Xaml layout components

            //Add error handling if no characters exist

            //Connect to local database and populate existing local characters list
            var db = new SQLiteConnection(dbPath); //Connect to local database
            charListView.ItemsSource = db.Table<Character>().OrderBy(x => x.Name).ToList(); //Populate the list view element with characters

        }
        private async void Button_Clicked(object sender, EventArgs e)
        {
            await Navigation.PushAsync(new CharCreatePage()); //Navigate to step 1/4 of the character creation process
        }

    }
}