﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CantripCrossPlatform.Assets;
using SQLite;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace CantripCrossPlatform
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class CharCreatePage : ContentPage
    {
        string dbPath = Path.Combine(System.Environment.GetFolderPath(System.Environment.SpecialFolder.Personal), "myDV.db3");
        public CharCreatePage()
        {
            this.Title = "New Character";
            InitializeComponent();

            //Populate race picker from list
            List<Race> races = new List<Race>();
            races.Add(new Race() { raceID = "dragonborn", description = "Dragonborn" });
            races.Add(new Race() { raceID = "dwarf", description = "Dwarf" });
            races.Add(new Race() { raceID = "elf", description = "Elf" });
            races.Add(new Race() { raceID = "gnome", description = "Gnome" });
            races.Add(new Race() { raceID = "halfElf", description = "Half Elf" });
            races.Add(new Race() { raceID = "halfling", description = "Halfling" });
            races.Add(new Race() { raceID = "halfOrc", description = "Half Orc" });
            races.Add(new Race() { raceID = "human", description = "Human" });
            races.Add(new Race() { raceID = "tiefling", description = "Tiefling" });
            pickerRace.ItemsSource = races;

            //Populate background picker from list
            var backgrounds = new List<String>() { "Acolyte", "Charlatan", "Criminal", "Entertainer", "Folk Hero", "Gladiator", "Guild Artisan", "Hermit", "Knight", "Noble", "Outlander", "Pirate", "Sage", "Sailor", "Soldier", "Urchin" };
            pickerBackground.ItemsSource = backgrounds;

            //Populate class objects
            List<Class> classes = new List<Class>();
            classes.Add(new Class() { classID = "barbarian", description = "Barbarian, a ferocious warrior who can enter a primitive battle rage." });
            classes.Add(new Class() { classID = "bard", description = "Bard, a talented musician that weaves magical effects into their words." });
            classes.Add(new Class() { classID = "cleric", description = "Cleric, a priest like champion that wields divine magic." });
            classes.Add(new Class() { classID = "druid", description = "Druid, a wielder of nature-themed magics." });
            classes.Add(new Class() { classID = "fighter", description = "Fighter, a versatile warrior who uses weapons, strategy and tactics." });
            classes.Add(new Class() { classID = "monk", description = "Monk, a mystic and master of the martial arts." });
            classes.Add(new Class() { classID = "paladin", description = "Paladin, a holy warrior that can cast divine magic." });
            classes.Add(new Class() { classID = "ranger", description = "Ranger, a protecter of the borderlands that uses nature magic and weapons in combat." });
            classes.Add(new Class() { classID = "rogue", description = "Rogue, a stealthy and dexterous character that uses trickery and stealth." });
            classes.Add(new Class() { classID = "sorcerer", description = "Sorcerer, a spellcaster who inherited their magic as a gift." });
            classes.Add(new Class() { classID = "warlock", description = "Warlock, a spellcaster who bargained with an extraplanar entity." });
            classes.Add(new Class() { classID = "wizard", description = "Wizard, a scholarly spellcaster who can manipulate reality." });
            cardClass.ItemsSource = classes;
            /*pickerClass.ItemsSource = classes;
            stackLayout.Children.Add(pickerClass);

            //Make this show class details
            pickerClass.SelectedIndexChanged += (object sender, EventArgs e) =>
            {
                var selectedClass = pickerClass.SelectedItem;
                if (selectedClass != null)
                {
                    //Fix this, need to pull the description
                    string classDetails = pickerClass.Items[pickerClass.SelectedIndex];
                    Label classLabel = new Label { Text = classDetails.ToString() };
                    stackLayout.Children.Add(classLabel);
                }
            };*/
        }
        private async void Button_Clicked(object sender, EventArgs e)
        {
            var db = new SQLiteConnection(dbPath); //Connect to local database  
            db.CreateTable<Character>(); //Create new instance of a character
            var maxPK = db.Table<Character>().OrderByDescending(c => c.characterID).FirstOrDefault();
            
            var selectedRace = pickerRace.SelectedItem;
            //var selectedClass = pickerClass.SelectedItem;
            var selectedBg = pickerBackground.SelectedItem;

            Character character = new Character()
            {
                characterID = (maxPK == null ? 1 : maxPK.characterID + 1),
                Name = entryName.Text,
                Race = selectedRace.ToString(),
                //Class = selectedClass.ToString(),
                Background = selectedBg.ToString(),
                TotalLevel = '1' //Characters start at lvl 1
            };
            
            db.Insert(character); //Insert new character table into the db
            await Navigation.PopAsync();
            await Navigation.PushAsync(new CharCreatePage2(character.characterID)); //Navigate to step 2/4 of the character creation process and pass the 'characterID'
        }
    }
}