﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CantripCrossPlatform.Assets;
using SQLite;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace CantripCrossPlatform
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class CharCreatePage : ContentPage
    {
        private Entry nameEntry;
        private Button createButton;
        private Picker pickerRace, pickerClass;
        //SQLite DB connection
        string dbPath = Path.Combine(System.Environment.GetFolderPath(System.Environment.SpecialFolder.Personal), "myDV.db3");
        public CharCreatePage()
        {
            this.Title = "Create Your Character";
            StackLayout stackLayout = new StackLayout();

            Label nameLabel = new Label { Text = "Character Name"};
            stackLayout.Children.Add(nameLabel);
            nameEntry = new Entry();
            nameEntry.Keyboard = Keyboard.Text;
            nameEntry.Placeholder = "Name";
            stackLayout.Children.Add(nameEntry);

            Label raceLabel = new Label { Text = "Race" };
            stackLayout.Children.Add(raceLabel);
            List<Race> races = new List<Race>();
            races.Add(new Race() { raceID = "dragonborn", description = "Dragonborn" });
            races.Add(new Race() { raceID = "dwarf", description = "Dwarf" });
            races.Add(new Race() { raceID = "elf", description = "Elf" });
            races.Add(new Race() { raceID = "gnome", description = "Gnome" });
            races.Add(new Race() { raceID = "halfElf", description = "Half Elf" });
            races.Add(new Race() { raceID = "halfling", description = "Halfling" });
            races.Add(new Race() { raceID = "halfOrc", description = "Half Orc" });
            races.Add(new Race() { raceID = "human", description = "Human" });
            races.Add(new Race() { raceID = "tiefling", description = "Tiefling" });

            pickerRace = new Picker();
            pickerRace.Title = "Select...";
            pickerRace.ItemsSource = races;
            stackLayout.Children.Add(pickerRace);

            //Add details label for race

            Label classTitleLabel = new Label { Text = "Class" };
            stackLayout.Children.Add(classTitleLabel);
            List<Class> classes = new List<Class>();
            classes.Add(new Class() { classID = "barbarian", description = "Barbarian, a ferocious warrior who can enter a primitive battle rage." });
            classes.Add(new Class() { classID = "bard", description = "Bard, a talented musician that weaves magical effects into their words." });
            classes.Add(new Class() { classID = "cleric", description = "Cleric, a priest like champion that wields divine magic." });
            classes.Add(new Class() { classID = "druid", description = "Druid, a wielder of nature-themed magics." });
            classes.Add(new Class() { classID = "fighter", description = "Fighter, a versatile warrior who uses weapons, strategy and tactics." });
            classes.Add(new Class() { classID = "monk", description = "Monk, a mystic and master of the martial arts." });
            classes.Add(new Class() { classID = "paladin", description = "Paladin, a holy warrior that can cast divine magic." });
            classes.Add(new Class() { classID = "ranger", description = "Ranger, a protecter of the borderlands that uses nature magic and weapons in combat." });
            classes.Add(new Class() { classID = "rogue", description = "Rogue, a stealthy and dexterous character that uses trickery and stealth." });
            classes.Add(new Class() { classID = "sorcerer", description = "Sorcerer, a spellcaster who inherited their magic as a gift." });
            classes.Add(new Class() { classID = "warlock", description = "Warlock, a spellcaster who bargained with an extraplanar entity." });
            classes.Add(new Class() { classID = "wizard", description = "Wizard, a scholarly spellcaster who can manipulate reality." });

            pickerClass = new Picker();
            pickerClass.Title = "Select...";
            pickerClass.ItemsSource = classes;
            stackLayout.Children.Add(pickerClass);

            pickerClass.SelectedIndexChanged += (object sender, EventArgs e) =>
            {
                var selectedClass = pickerClass.SelectedItem;
                if (selectedClass != null)
                {
                    //Fix this, need to pull the description
                    string classDetails = pickerClass.Items[pickerClass.SelectedIndex];
                    Label classLabel = new Label { Text = classDetails.ToString() };
                    stackLayout.Children.Add(classLabel);
                }
            };

            createButton = new Button();
            createButton.Text = "N E X T";
            createButton.Clicked += Button_Clicked;
            stackLayout.Children.Add(createButton);

            Content = stackLayout;
        }
        private async void Button_Clicked(object sender, EventArgs e)
        {
            var db = new SQLiteConnection(dbPath);
            db.CreateTable<Character>();
            var maxPK = db.Table<Character>().OrderByDescending(c => c.characterID).FirstOrDefault();
            var selectedRace = pickerRace.SelectedItem;
            var selectedClass = pickerClass.SelectedItem;

            Character character = new Character()
            {
                characterID = (maxPK == null ? 1 : maxPK.characterID + 1),
                Name = nameEntry.Text,
                Race = selectedRace.ToString(),
                Class = selectedClass.ToString()
            };
            //Insert new character into the db
            db.Insert(character);
            await DisplayAlert(null, character.Name + " Created", "Ok");
            await Navigation.PopAsync();
        }
    }
}