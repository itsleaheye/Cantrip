﻿using CantripCrossPlatform.Assets;
using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;
using SQLite;

namespace CantripCrossPlatform.Models
{
    [DataObject]
    public class CharacterVM
    {
        public List<Character> Characters { get; set; }
        /*public CharacterModel()
        {
            Characters = Character.ToString();
        }*/
    }
}
