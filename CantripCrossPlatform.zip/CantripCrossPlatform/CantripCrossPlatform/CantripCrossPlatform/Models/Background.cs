﻿using System;
using System.Collections.Generic;
using SQLite;
using System.Text;

namespace CantripCrossPlatform.Assets
{
    public class Background
    {
        [PrimaryKey]
        public string backgroundID { get; set; } //Primary key declaration

        public string language { get; set; } //language
    }
}
