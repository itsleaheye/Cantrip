﻿using CantripCrossPlatform.Assets;
using System;
using System.Collections.Generic;
using System.Text;

namespace CantripCrossPlatform.Models
{
    public class CharacterModel
    {
        public List<Character> Characters { get; set; }
        /*public CharacterModel()
        {
            Characters = Character.ToString();
        }*/
    }
}
