﻿using System;
using SQLite;
using System.Collections.Generic;
using System.Text;

namespace CantripCrossPlatform.Assets
{
    public class Character
    {
        [PrimaryKey]
        public int characterID { get; set; }

        public string Name { get; set; }
        public string Race { get; set; }
        public string Class { get; set; }

        public override string ToString()
        {
            return this.Name + " \n" + this.Race + " " + this.Class;
        }
    }
}
