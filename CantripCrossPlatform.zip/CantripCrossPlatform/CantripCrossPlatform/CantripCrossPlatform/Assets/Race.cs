﻿using System;
using SQLite;
using System.Collections.Generic;
using System.Text;

namespace CantripCrossPlatform.Assets
{
    public class Race
    {
        [PrimaryKey]
        public string raceID { get; set; }
        public string description { get; set; }
        public override string ToString()
        {
            return this.description;
        }
    }
}
