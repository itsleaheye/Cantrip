﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SQLite;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace CantripCrossPlatform
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class CharCreatePage2 : ContentPage
    {
        //SQLite DB connection
        string dbPath = Path.Combine(System.Environment.GetFolderPath(System.Environment.SpecialFolder.Personal), "myDV.db3");
        public CharCreatePage2(int characterID)
        {
            this.Title = "Abilities";
            InitializeComponent();
              
        }
        private async void Button_Clicked(object sender, EventArgs e)
        {
            await Navigation.PushAsync(new CharCreatePage3()); //Navigate to step 3/4 of the character creation process
        }
    }
}