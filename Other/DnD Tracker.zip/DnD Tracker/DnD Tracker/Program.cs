﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DnD_Tracker
{
    class Program
    {
        static void Main(string[] args)
        {
            //int menuOption = 0;
            string[] characterDetails = new string[20]; //stand in array before we code in objects as our characters
            string racialBonus, backgroundBonus;
            Console.WriteLine("text");
            DisplayMenu();
            //menuOption = GetMenuOption();
            //Console.WriteLine(menuOption); <this proves its the right menu option
            Console.ReadLine();
        }
        static void DisplayMenu()
        {
            Console.Clear();
            Console.WriteLine("====================================\n  Welcome to DnD Character Tracker \n====================================");
            Console.WriteLine("\n1) Create New Character \n2) Load Character \n3) Edit Character \n4) Delete Character \n5) Export Character");
            Console.WriteLine("\n====================================");
        }
        static void GetMenuOption()
        {
            int menuOption;
            Console.Write("Your Choice: ");
            menuOption = int.Parse(Console.ReadLine());
            Console.WriteLine("====================================");
            //switch (menuOption)
            //{
                //case 0:
                    //{
                        //CharacterCreation();
                        //break;
                    //}
            //}
        }

        static void CharacterCreation(string[] characterDetails)
        {
            Console.Clear();
            Console.WriteLine("====================================\n  Character Creation \n====================================");
            Console.WriteLine("Race: ");
            characterDetails[0] = Console.ReadLine();
            Console.WriteLine("Subrace: ");
            characterDetails[1] = Console.ReadLine();
            Console.WriteLine("Class: ");
            characterDetails[2] = Console.ReadLine();
            Console.WriteLine("Background: ");
            characterDetails[3] = Console.ReadLine();
        }

        //create validator for menu option
    }
}
